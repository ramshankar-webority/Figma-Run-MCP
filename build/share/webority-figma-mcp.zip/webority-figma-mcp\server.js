// Webority Figma Write MCP (v1.1.0): MCP server over stdio.
// Lets Claude read and write the Figma file open in Figma desktop, through the
// "Webority Figma Write" plugin. Local only: port 3692, per-machine token, no Figma rate limits.
// stdout is the MCP protocol; every log line goes to stderr.

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { FigmaWriteBridge } from "./bridge.js";
import { registerExtraTools } from "./lib/tools-extra.js";
import { registerReadTools } from "./lib/tools-read.js";
import { registerOpenTools } from "./lib/tools-open.js";

export const VERSION = "1.1.0";
const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.FIGMA_WRITE_PORT || 3692);
const log = (line) => process.stderr.write(line + "\n");

// Per-machine token, created once, stamped into the plugin UI on every start.
function ensureToken() {
  const file = path.join(here, ".bridge-token");
  if (!fs.existsSync(file)) fs.writeFileSync(file, crypto.randomBytes(32).toString("hex"), { mode: 0o600 });
  return fs.readFileSync(file, "utf8").trim();
}
function stampPluginUi(token) {
  const template = fs.readFileSync(path.join(here, "plugin", "ui.template.html"), "utf8");
  // Bricolage Grotesque is embedded: the plugin iframe may only reach the local bridge.
  const font = fs.readFileSync(path.join(here, "plugin", "bricolage-grotesque-latin.woff2")).toString("base64");
  const html = template
    .replaceAll("__BRIDGE_TOKEN__", token)
    .replaceAll("__BRIDGE_PORT__", String(PORT))
    .replaceAll("__VERSION__", VERSION)
    .replaceAll("__FONT_B64__", font);
  const target = path.join(here, "plugin", "ui.html");
  if (!fs.existsSync(target) || fs.readFileSync(target, "utf8") !== html) fs.writeFileSync(target, html);
}

const token = ensureToken();
// Tests run the server on a random port; they must never rewrite the real plugin UI.
if (!process.env.FIGMA_WRITE_NO_STAMP) stampPluginUi(token);

// Lazy bind: the port is claimed on the first tool call, so several Claude sessions can have this
// MCP registered and only the session that actually uses Figma owns the plugin connection.
const bridge = new FigmaWriteBridge({ port: PORT, token, log });
if (process.env.FIGMA_WRITE_EAGER === "1") await bridge.start();

const server = new McpServer({ name: "webority-figma-write", version: VERSION });

const text = (value) => ({ content: [{ type: "text", text: typeof value === "string" ? value : JSON.stringify(value) }] });
const fail = (e) => ({ isError: true, content: [{ type: "text", text: e instanceof Error ? e.message : String(e) }] });
const call = async (command, params, timeoutMs) => {
  try {
    return text(await bridge.request(command, params, timeoutMs));
  } catch (e) {
    return fail(e);
  }
};

server.registerTool(
  "figma_write_status",
  {
    description:
      "Status of the Webority Figma Write bridge: whether the 'Webority Figma Write' plugin is connected, which file and page it has open, editor type (design editor or Dev Mode), selection count, whether 'Allow edits' is ticked, and plugin vs server version. Call first, and whenever another figma_* write tool fails.",
    annotations: { readOnlyHint: true },
  },
  async () => {
    if (!bridge.bound) await bridge.start();
    const status = { server: VERSION, ...bridge.status() };
    if (!status.connected) {
      return text({ ...status, hint: bridge.bound ? "Open the 'Webority Figma Write' plugin in Figma desktop (design editor) and keep it open." : status.bridge });
    }
    if (status.version && status.version !== VERSION) status.warning = `Plugin build ${status.version} differs from server ${VERSION}. Close and reopen the plugin in Figma.`;
    try {
      return text({ ...status, ...(await bridge.request("status", {}, 10000)) });
    } catch (e) {
      return text({ ...status, statusError: e.message });
    }
  }
);

server.registerTool(
  "figma_get_selection_brief",
  {
    description: "Ids, names, types, sizes and parent of the nodes currently selected in Figma. Use it to target edits at 'this one' after the user selects something.",
    annotations: { readOnlyHint: true },
  },
  async () => call("selection_brief", {}, 15000)
);

server.registerTool(
  "figma_export",
  {
    description:
      "Render a node (frame, section, layer) to PNG, JPG or SVG and return it so you can check your work visually. SVG keeps icons and illustrations as vectors. Optionally also save it to a local file. Works in the design editor and Dev Mode; does not need 'Allow edits'.",
    inputSchema: {
      nodeId: z.string().min(1).describe("Node id, e.g. '826:2'. A Figma URL node-id like '826-2' also works."),
      format: z.enum(["PNG", "JPG", "SVG"]).optional().describe("Default PNG."),
      scale: z.number().min(0.05).max(4).optional().describe("Default 1. Use 0.25-0.5 for large frames. Ignored for SVG."),
      savePath: z.string().optional().describe("Absolute local path to also write the file to."),
    },
    annotations: { readOnlyHint: true },
  },
  async ({ nodeId, format = "PNG", scale = 1, savePath }) => {
    try {
      const id = nodeId.includes("-") && !nodeId.includes(":") ? nodeId.replace("-", ":") : nodeId;
      const r = await bridge.request("export", { nodeId: id, format, scale }, 90000);
      const bytes = Buffer.from(r.base64, "base64");
      if (savePath) fs.writeFileSync(savePath, bytes);
      const info = { node: r.node, format, width: r.width, height: r.height, bytes: bytes.length, saved: savePath || null };
      // SVG is text, so it comes back as markup rather than an image block.
      if (format === "SVG") return text({ ...info, svg: bytes.toString("utf8").slice(0, 20000) });
      return {
        content: [
          { type: "image", data: r.base64, mimeType: format === "JPG" ? "image/jpeg" : "image/png" },
          { type: "text", text: JSON.stringify(info) },
        ],
      };
    } catch (e) {
      return fail(e);
    }
  }
);

server.registerTool(
  "figma_export_many",
  {
    description:
      "Export many nodes to files in one call, as PNG, JPG or SVG. Returns only a list of what was written, never the images themselves, so it stays cheap for bulk asset extraction (icons, illustrations, screenshots for a rebuild). Does not need 'Allow edits'.",
    inputSchema: {
      items: z
        .array(
          z.object({
            nodeId: z.string().min(1),
            savePath: z.string().min(1).describe("Absolute path to write to. Parent folders are created."),
            format: z.enum(["PNG", "JPG", "SVG"]).optional(),
            scale: z.number().min(0.05).max(4).optional(),
          })
        )
        .min(1)
        .max(500),
      stopOnError: z.boolean().optional().describe("Stop at the first failure. Default false: every item is tried and reported."),
    },
    annotations: { readOnlyHint: true },
  },
  async ({ items, stopOnError = false }) => {
    const results = [];
    for (const item of items) {
      try {
        const id = item.nodeId.includes("-") && !item.nodeId.includes(":") ? item.nodeId.replace(/-/g, ":") : item.nodeId;
        const format = item.format || "PNG";
        const r = await bridge.request("export", { nodeId: id, format, scale: item.scale || 1 }, 90000);
        const bytes = Buffer.from(r.base64, "base64");
        if (!path.isAbsolute(item.savePath)) throw new Error("savePath must be absolute: " + item.savePath);
        fs.mkdirSync(path.dirname(item.savePath), { recursive: true });
        fs.writeFileSync(item.savePath, bytes);
        results.push({ nodeId: item.nodeId, name: r.node && r.node.name, format, width: r.width, height: r.height, bytes: bytes.length, saved: item.savePath });
      } catch (e) {
        results.push({ nodeId: item.nodeId, error: e.message });
        if (stopOnError) break;
      }
    }
    const ok = results.filter((r) => !r.error);
    return text({ exported: ok.length, failed: results.length - ok.length, notTried: items.length - results.length, totalBytes: ok.reduce((n, r) => n + r.bytes, 0), results });
  }
);

server.registerTool(
  "figma_execute",
  {
    description:
      "Run Figma Plugin API JavaScript inside the open file (design editor only, needs 'Allow edits' ticked in the plugin panel). The code runs as the body of an async function: use await, and `return` a value to get it back as JSON (nodes come back as {id,name,type}). The global `figma` is the Plugin API. Load fonts with figma.loadFontAsync before setting text. All changes from one call form a single undo step. Keep each call focused; very large loops freeze Figma until they finish. Note: the Plugin API cannot set OpenType features (e.g. lining figures); copy a layer that already has them and edit its characters instead.",
    inputSchema: {
      code: z.string().min(1).describe("JavaScript body, e.g. `const f = figma.createFrame(); f.name = 'Card'; return f;`"),
      timeoutMs: z.number().int().min(1000).max(120000).optional().describe("Default 30000."),
    },
    annotations: { destructiveHint: true, readOnlyHint: false },
  },
  async ({ code, timeoutMs = 30000 }) => call("execute", { code, timeoutMs }, timeoutMs + 5000)
);

server.registerTool(
  "figma_set_text",
  {
    description: "Replace the characters of one or more text layers. Fonts used in each layer are loaded automatically. Needs 'Allow edits'. One undo step.",
    inputSchema: {
      edits: z.array(z.object({ nodeId: z.string().min(1), characters: z.string() })).min(1).max(500),
    },
    annotations: { destructiveHint: true, readOnlyHint: false },
  },
  async ({ edits }) => call("set_text", { edits }, 60000)
);

const specShape = z.lazy(() =>
  z.object({
    type: z.enum(["FRAME", "TEXT", "RECTANGLE", "ELLIPSE"]),
    name: z.string().optional(),
    x: z.number().optional(),
    y: z.number().optional(),
    width: z.number().positive().optional(),
    height: z.number().positive().optional(),
    fill: z.string().optional().describe("Hex, e.g. #FF5733 or #FF573380 (with alpha). Use 'none' for no fill."),
    stroke: z.string().optional(),
    strokeWeight: z.number().min(0).optional(),
    cornerRadius: z.number().min(0).optional(),
    opacity: z.number().min(0).max(1).optional(),
    clipsContent: z.boolean().optional(),
    layout: z
      .object({
        mode: z.enum(["HORIZONTAL", "VERTICAL"]),
        padding: z.union([z.number(), z.object({ top: z.number(), right: z.number(), bottom: z.number(), left: z.number() })]).optional(),
        gap: z.number().optional(),
        primaryAlign: z.enum(["MIN", "CENTER", "MAX", "SPACE_BETWEEN"]).optional(),
        counterAlign: z.enum(["MIN", "CENTER", "MAX", "BASELINE"]).optional(),
        wrap: z.boolean().optional(),
      })
      .optional(),
    sizing: z
      .object({ horizontal: z.enum(["FIXED", "HUG", "FILL"]).optional(), vertical: z.enum(["FIXED", "HUG", "FILL"]).optional() })
      .optional()
      .describe("FILL needs an auto-layout parent; HUG needs auto layout on this frame or a text node."),
    text: z
      .object({
        characters: z.string(),
        fontFamily: z.string().optional().describe("Default Inter"),
        fontStyle: z.string().optional().describe("Default Regular"),
        fontSize: z.number().positive().optional(),
        color: z.string().optional(),
        lineHeight: z.number().positive().optional().describe("Pixels"),
        letterSpacing: z.number().optional().describe("Pixels"),
        align: z.enum(["LEFT", "CENTER", "RIGHT", "JUSTIFIED"]).optional(),
      })
      .optional(),
    children: z.array(specShape).optional(),
  })
);

server.registerTool(
  "figma_create_from_spec",
  {
    description:
      "Build a whole layer tree in one call from a JSON spec: frames with auto layout, padding, gap, Fill/Hug/Fixed sizing, fills, strokes, radius, and text with font, size, colour, line height. Placed on the current page (or inside parentId), then selected and zoomed into view. Needs 'Allow edits'. One undo step.",
    inputSchema: {
      spec: specShape,
      parentId: z.string().optional().describe("Frame to append into. Omit for the current page."),
      select: z.boolean().optional().describe("Select and zoom to the result. Default true."),
    },
    annotations: { destructiveHint: false, readOnlyHint: false },
  },
  async ({ spec, parentId, select = true }) => call("create_from_spec", { spec, parentId, select }, 60000)
);

// Code Connect, shaders, generative plugins and video (lib/tools-extra.js).
// Tests point the library at a temp folder so they never touch the real one.
registerExtraTools({ server, bridge, here, text, fail, call, libraryDir: process.env.FIGMA_WRITE_LIBRARY_DIR });

// Structured reads: metadata, document, node, find, text, styles, variables, image (lib/tools-read.js).
registerReadTools({ server, bridge, text, fail, call });

// For people who cannot run the plugin: repo-stored code maps and REST reading (lib/tools-open.js).
registerOpenTools({ server, bridge, text, fail });

await server.connect(new StdioServerTransport());
log(`[webority-figma-write ${VERSION}] MCP server ready (bridge port ${PORT}, binds on first use)`);

const shutdown = async () => {
  await bridge.stop();
  process.exit(0);
};
process.stdin.on("close", shutdown);
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
