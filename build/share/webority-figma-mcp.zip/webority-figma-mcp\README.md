# Webority Figma Write MCP · v1.1.0 (44 tools)

Lets Claude **read and write the Figma file open in Figma desktop**: create layouts, edit text, run any Figma Plugin API code, and export images to check its own work. It runs entirely on your PC through a small Figma plugin, so there are **no Figma MCP rate limits** and no plan restrictions beyond having edit access to the file.

Proven on 15-Sep-2026: built the Capnix social carousels (22 posts) and the Pulse music player screens in real Figma files.

---

## 1. Install (once per machine)

**Needs:** Figma desktop app, Node.js 20+, Claude Code.

```bash
# 1. dependencies (already installed in this folder)
cd "C:/Dev/Figma Run MCP/webority-figma-write"
npm install

# 2. register with Claude Code for all projects
claude mcp add -s user Figma-MCP-Webority -- node "C:/Dev/Figma Run MCP/webority-figma-write/server.js"

# 3. restart Claude Code (or /clear) so the tools load
```

**Import the plugin in Figma** (once):
Figma desktop → open any design file → right-click canvas → **Plugins → Development → Import plugin from manifest…** →
`C:\Dev\Figma Run MCP\webority-figma-write\plugin\manifest.json`

> If you used the earlier prototype, remove **"Webority Figma Write (prototype)"** from Plugins → Development → Manage plugins in development. The final plugin is a separate entry named **Webority Figma Write**.

---

## 2. Use it

1. Open the Figma file and make sure you are in the **design editor** (right sidebar shows **Design / Prototype**, not Inspect / Plugins). Press **Shift + D** to leave Dev Mode.
2. Right-click canvas → **Plugins → Development → Webority Figma Write**. A floating panel opens.
3. Tick **Allow edits** when you want Claude to change the file. Untick to lock it.
4. Ask Claude, e.g. *"Build a pricing card on this page"*, *"Change every ₹ amount in this frame"*, *"Export frame 826:2 so you can check it"*.

The panel turns green once Claude makes its first Figma call ("Connected to Claude"). Until then it shows a grey "Waiting for Claude…" and retries every 2 seconds; that is normal.

---

## 3. Tools

All 44 tools, grouped: core 7, reading 10, Code Connect 7, shaders 6, generative plugins 5, video 1, open access 8. "Needs Allow edits" means the tick box in the plugin panel.

### Core (7)

| Tool | Writes? | Needs Allow edits | Does |
|---|---|---|---|
| `figma_write_status` | No | No | Connection, file, page, editor type, selection count, Allow edits state, plugin vs server version |
| `figma_get_selection_brief` | No | No | Ids, names, sizes and parent of the current selection |
| `figma_export` | No | No | Render a node to PNG, JPG or SVG, optionally saving it |
| `figma_export_many` | No | No | Export up to 500 nodes to files in one call, returning only a manifest |
| `figma_execute` | Yes | Yes | Run any Plugin API JavaScript. One undo step per call |
| `figma_set_text` | Yes | Yes | Replace text in one or many layers, fonts loaded automatically |
| `figma_create_from_spec` | Yes | Yes | Build a layer tree from JSON: frames, auto layout, fills, text |



## Developers on a free plan with view-only access

They cannot run the plugin (it needs edit access) and Figma gives View and Collab seats only about **20 file or image REST requests a month**. The MCP handles that for them: **the same read and Code Connect tools work, with no Figma access at all.**

**Setup, once per project.** Someone who can open the file runs:

```
figma_save_snapshot  savePath: <repo>/.figma/design-snapshot.json  codeMapRepo: <repo>
```

Commit `.figma/`. That is it.

**After that, a view-only developer just calls the tools.** No arguments, no token, no Figma open:

| They call | What happens |
|---|---|
| `figma_access_check` | Says exactly what works on their machine and what to do next |
| `figma_get_metadata`, `figma_get_document`, `figma_get_node`, `figma_find_nodes`, `figma_get_text`, `figma_get_styles`, `figma_get_variable_defs` | Answered from the snapshot when no plugin is connected. Pass `snapshot` to point at a different one |
| `figma_get_code_connect_map` | Reads `.figma/code-map.json` plus the snapshot, resolving an instance to the component behind it |
| `figma_add_code_connect_map` | Saves into the repo store instead of failing, and says how to push it into Figma later |
| `figma_snapshot_code_map` | Every mapping in the snapshot |
| `figma_rest_file`, `figma_rest_images` | Optional: live reads with their own token, cached, within the monthly seat budget |

The snapshot is found automatically: `FIGMA_SNAPSHOT`, else `FIGMA_PROJECT_DIR`, else the nearest `.figma` folder walking up from the working directory.

**Verified with no plugin connected:** metadata returned "snapshot | Webority Partners V_2.0 | 1129 layers", a text search found its layers with paths, `figma_get_node` returned Zalando Sans SemiBold 16px on `#252f4a`, variables returned the three brand colours, and `figma_get_code_connect_map` for node `3444:5120` returned `AppButton` from the repo store.

### Open access: readers without a Figma seat (8 tools)

The plugin needs edit access, and Figma gives View or Collab seats only about **20 file or image REST requests a month**, so free teammates cannot drive Figma live. These tools give them the design anyway.

| Tool | Does |
|---|---|
| `figma_access_check` | What this machine can do right now: plugin, snapshot, REST token and budget, repo mappings, and the route that works |
| `figma_get_repo_code_map` | Read Code Connect mappings stored in a repo (`.figma/code-map.json`), no Figma access needed |
| `figma_set_repo_code_map` | Save a mapping in the repo instead of the file, reviewable in a pull request |
| `figma_remove_repo_code_map` | Remove one |
| `figma_sync_code_map` | `pull` copies the file's mappings into the repo, `push` writes the repo's mappings into Figma (needs edit access) |
| `figma_rest_status` | Whether a personal access token is present and how many REST calls this machine spent this month |
| `figma_rest_file` | Read a file or node through the REST API with the reader's own token, cached on disk |
| `figma_rest_images` | Render nodes to images through REST, optionally downloading them |

**Offline design viewer:** `node tools/make-viewer.mjs <design.json> <outDir> [render.png] [code-map.json]` builds a single `viewer.html`: layer tree, search across names and copy, a click-to-highlight canvas over the exported render, and a specs panel with size, sizing, constraints, auto layout, fills with hex, type, variables, styles, component properties, the code mapping and copyable CSS. It opens with no Figma account, no seat, no token and no network.

### Reading a design (10 tools)

Richer than the read-only weborityos plugin on port 3691: these also return Fill/Hug sizing, min and max, constraints, component and variant properties, the main component behind an instance, line height and letter spacing, mixed text runs, style links by name, bound variables by name, per-corner radius, blend mode, rotation, masks and prototype links.

| Tool | Does |
|---|---|
| `figma_get_metadata` | Every page with its layer count and top-level frames |
| `figma_get_document` | A page's layer tree, with depth and node limits |
| `figma_get_node` | One layer in full detail, with children |
| `figma_find_nodes` | Find layers by name, type or text, with their layer path |
| `figma_get_text` | Every text layer with content, font, size, colour and style |
| `figma_get_styles` | Local paint, text, effect and grid styles |
| `figma_get_variable_defs` | Variable collections, modes and values, aliases resolved |
| `figma_save_image` | The original bytes behind an image fill |
| `figma_save_snapshot` | Save the whole design to one JSON file, so every read tool works later with no Figma at all |
| `figma_snapshot_code_map` | The code mappings baked into a snapshot: which component each layer uses, and its code component |

### Code Connect (local, works on the Pro plan)

Figma's own Code Connect needs an Organization or Enterprise plan. These tools store the mapping **inside the Figma file** instead. Anyone can see it in Dev Mode by choosing the **Webority code map** code generator. A source that is an https URL is also added as a Dev Mode link.

| Tool | Writes? | Needs Allow edits | Does |
|---|---|---|---|
| `figma_list_file_components_for_code_connect` | No | No | Components and component sets, their properties, variants and current mapping |
| `figma_get_code_connect_map` | No | No | One component's mapping and code preview, or every mapped component |
| `figma_add_code_connect_map` | Yes | Yes | Map one component to a code component (name, source, import, prop names, template) |
| `figma_send_code_connect_mappings` | Yes | Yes | Save many mappings at once, with a result per item |
| `figma_remove_code_connect_map` | Yes | Yes | Remove a mapping |
| `figma_get_code_connect_suggestions` | No | No | Scan a local code folder and suggest matches with a confidence score |
| `figma_get_context_for_code_connect` | No | No | Props, mapping, image, the mapped source file and match candidates for one component |

### Shaders

The Figma Plugin API has no GLSL shaders. A Webority shader is a saved recipe with two optional parts. **Pixel code** is a small JavaScript function rendered on your PC into an image fill (up to 4096 px). **Effects** are native Figma glass, noise, texture, glow, shadow and blurs. Built-ins: every effect, plus **Aurora gradient** and **Film grain**. Your shaders are saved in `library/shaders/`.

| Tool | Writes? | Needs Allow edits | Does |
|---|---|---|---|
| `figma_create_shader` | Library | No | Save a new shader, returns a preview image |
| `figma_get_shader` | No | No | One shader with its code and a preview |
| `figma_update_shader` | Library | No | Change a shader, bumps its version |
| `figma_list_shaders` | No | No | Built-in and library shaders |
| `figma_list_file_shaders` | No | No | Which layers in the file use which shader, and which are behind the latest version |
| `figma_apply_shader` | Yes | Yes | Render and apply a shader to layers, with param overrides |

### Generative plugins

Saved, reusable Plugin API scripts with parameters, for example "12-column grid" or "avatar placeholders". Saved in `library/generative-plugins/`. They are not Figma's cloud AI plugins; Claude writes the code once and you rerun it on any file.

| Tool | Writes? | Needs Allow edits | Does |
|---|---|---|---|
| `figma_create_generative_plugin` | Library | No | Save code plus parameter definitions |
| `figma_get_generative_plugin` | No | No | Code, parameters, version, run count |
| `figma_update_generative_plugin` | Library | No | Change it, bumps its version |
| `figma_list_generative_plugins` | No | No | Everything saved |
| `figma_run_generative_plugin` | Yes | Yes | Run it on the open file with parameters |

### Video

| Tool | Writes? | Needs Allow edits | Does |
|---|---|---|---|
| `figma_export_video` | File on disk | Only for `animate` | MP4, WebM or GIF from a list of frames, the children of a section, or an animation script run on a temporary copy of a layer. Uses the bundled ffmpeg |

---

## 4. Safety

- **Local only:** listens on `127.0.0.1` / `::1` port 3692, never the network.
- **Access checks on every connection:**
  - The Host header must be localhost (blocks DNS rebinding).
  - The Origin must be `null`, the Figma plugin iframe (blocks web pages).
  - A per-machine secret token must be sent (`.bridge-token`, stamped into the plugin).
- **One plugin window at a time:** a newer window takes over, and the old one shows "Another Figma window took over", so writes never land in the wrong file.
- **Edits are opt-in:** refused unless **Allow edits** is ticked, and always refused in Dev Mode.
- **Undo:** every call is one Ctrl+Z.
- **Destructive tools** (`figma_execute`, `figma_set_text`) are flagged, so Claude Code asks before running them unless you allow them.
- **Keep `.bridge-token` private.** Delete it to rotate; the server makes a new one, then reopen the plugin.

---

## 5. Troubleshooting

| You see | Cause | Fix |
|---|---|---|
| Panel: "Waiting for Claude…" (grey) | Normal idle state: no Claude session has made a Figma request yet, or the session ended | Ask Claude anything in Figma, e.g. run `figma_write_status` |
| Panel: "Rejected: token mismatch" | Token rotated or old plugin copy | Close and reopen the plugin |
| Panel: "Another Figma window took over" | Plugin open in a second file | Keep it open in one file; click Reconnect in the one you want |
| Red line "DEV MODE: read-only" | Plugin opened in Dev Mode | Close plugin, Shift + D, reopen in design editor |
| "Edits are off" | Allow edits unticked (it resets every time the plugin opens) | Tick Allow edits |
| "Port 3692 is already in use" | Another Claude session is using it | Use that session, or close it |
| Manifest error "editorType does not include dev" | Old prototype manifest | Import this folder's `plugin/manifest.json` |
| `figma_status` in weborityos shows a different file | That is the separate read-only Webority plugin on port 3691 | Both can run side by side |

**Plugin API limits to know:** fonts must be available in Figma; OpenType features (e.g. lining figures) can't be set directly (copy a layer that has them and edit its characters); image fills need bytes passed in code (≤ 4096 px); huge loops block Figma until they finish.

---

## 6. Files

| Path | Role |
|---|---|
| `server.js` | MCP server (stdio), the core 7 tools, lazy port bind, version 1.1.0 |
| `bridge.js` | Secure WebSocket bridge (Host, Origin, token, single plugin, shared bind) |
| `plugin/manifest.json` · `code.js` · `ui.template.html` | Figma plugin (`ui.html` is generated with the token and font) |
| `lib/tools-read.js` | 10 structured reads, including `figma_save_snapshot` and `figma_snapshot_code_map`. Every read accepts a `snapshot` |
| `lib/tools-extra.js` | 19 tools: Code Connect (7), shaders (6), generative plugins (5), video (1) |
| `lib/tools-open.js` | 8 no-seat tools: access check, repo code map (3), sync, REST reading (3) |
| `lib/snapshot.js` · `code-map-repo.js` · `rest.js` | Design snapshots and project lookup, `.figma/code-map.json`, REST with a budget-aware cache |
| `lib/shaders.js` · `png.js` · `code-scan.js` · `video.js` · `library.js` | Pixel shader renderer, PNG encoder, code scanner, ffmpeg wrapper, JSON library |
| `library/` | Your saved shaders and generative plugins (created on first save) |
| `test.js` | 16 automated checks (`npm test`), including real ffmpeg encodes and the no-seat path |
| `tools/live-check-1.1.mjs` | 24 checks against real Figma (needs the plugin and Allow edits) |
| `tools/demo-all-tools.mjs` | Calls every tool once against the open file |
| `tools/plan-assets.mjs` · `figma-to-html.mjs` · `merge-code-connect.mjs` · `make-viewer.mjs` | The Figma-to-HTML rebuild pipeline and the offline viewer generator |
| `design-run.js` · `designs/` | Runs a folder of design scripts against Figma |

**Changelog 1.1.0:**
- **No-seat access:** design snapshots (`figma_save_snapshot`), so every read tool answers with no Figma, no plugin and no seat; Code Connect falls back to `.figma/code-map.json`; `figma_access_check` explains what works on a given machine. Verified against the real Partners file, 12/12 checks with the plugin disconnected.
- **Rebuild pipeline:** `plan-assets`, `figma-to-html`, `merge-code-connect` and `make-viewer` turn a frame into a pixel-exact HTML page (0.927 SSIM on the worked example) plus an offline viewer.
- **Open access:** repo-stored Code Connect, REST reading with the reader's own token, and an offline design viewer, so teammates on free or view-only seats can read the design and the code map.
- **Reading:** 10 structured read tools, so this MCP no longer needs the port 3691 plugin for reading.
- **Renamed in Claude Code:** the MCP is registered as `Figma-MCP-Webority` (the folder and plugin names are unchanged).
- **Code Connect (local):** 7 tools. Mappings saved in the file, shown in Dev Mode by the plugin's code generator, suggestions from a local code scan.
- **Shaders:** 6 tools. Pixel code rendered to image fills plus native effects, with a versioned library and per-layer tracking.
- **Generative plugins:** 5 tools. Saved, parameterised Plugin API scripts.
- **Video:** `figma_export_video` for MP4, WebM and GIF, as a slideshow or a scripted animation.
- **After updating:** close and reopen the plugin in Figma so it loads the new commands.

**Changelog 1.0.0** (from prototype 0.1.0):
- **Renamed:** now "Webority Figma Write".
- **New tool:** `figma_export`.
- **Lazy port bind:** multi-session friendly, with a fix for simultaneous tool calls.
- **Version handshake and warning** between plugin and server.
- **Clean shutdown:** the bridge no longer hangs on stop.
- **Test isolation:** tests can no longer overwrite the plugin port.
- **Dev Mode:** the plugin opens there and shows a clear read-only notice.
