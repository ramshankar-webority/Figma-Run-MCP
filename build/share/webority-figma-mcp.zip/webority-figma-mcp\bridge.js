// Webority Figma Write MCP v1.0.0: local WebSocket bridge between the MCP server and the Figma plugin.
//
// Security model (the part weborityos's read-only bridge lacks, and a write bridge cannot skip):
//   1. Loopback only: listens on 127.0.0.1 and ::1, never a network interface.
//   2. Host check: every HTTP request / upgrade must name localhost, 127.0.0.1 or [::1] on our port.
//      This blocks DNS-rebinding pages that point an attacker hostname at 127.0.0.1.
//   3. Origin check: a browser always sends Origin. Only "null" (Figma's sandboxed plugin iframe)
//      is accepted. Non-browser clients can forge Origin, which is why 4 exists.
//   4. Token: the first message must be {hello, token} with the per-machine secret stamped into
//      the plugin UI. Wrong or missing token closes the socket with 4401.
//   5. One plugin at a time: a newly authenticated plugin replaces the old one, which is closed
//      with 4000 so writes never silently land in a different file.

import http from "node:http";
import crypto from "node:crypto";
import { WebSocketServer } from "ws";

export const CLOSE_REPLACED = 4000;
export const CLOSE_BAD_TOKEN = 4401;

export class FigmaWriteBridge {
  constructor({ port, token, allowedOrigins = ["null"], log = () => {} }) {
    this.port = port;
    this.token = token;
    this.allowedOrigins = allowedOrigins;
    this.log = log;
    this.servers = [];
    this.plugin = null; // { socket, state }
    this.pending = new Map();
    this.seq = 0;
    this.bound = false;
    this.bindError = null;
  }

  get allowedHosts() {
    const p = String(this.port);
    return new Set([`localhost:${p}`, `127.0.0.1:${p}`, `[::1]:${p}`]);
  }

  // Concurrent callers (several tool calls arriving together) share one bind attempt.
  start() {
    if (this.bound) return Promise.resolve(true);
    if (!this.starting) this.starting = this.#bind().finally(() => { this.starting = null; });
    return this.starting;
  }

  async #bind() {
    const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 * 1024 });
    this.wss = wss;
    const make = () => {
      const server = http.createServer((req, res) => {
        // No HTTP API at all: nothing to call, nothing to rebind onto.
        res.writeHead(this.hostAllowed(req) ? 404 : 421, { "Content-Type": "text/plain" });
        res.end();
      });
      server.on("upgrade", (req, socket, head) => this.onUpgrade(req, socket, head));
      return server;
    };
    try {
      const v4 = make();
      await listen(v4, "127.0.0.1", this.port);
      this.servers.push(v4);
      const v6 = make();
      try {
        await listen(v6, "::1", this.port);
        this.servers.push(v6);
      } catch (e) {
        // IPv6 loopback unavailable on some machines; Figma may resolve localhost to ::1, so warn.
        this.log(`[bridge] IPv6 loopback not bound (${e.code}); plugin must reach 127.0.0.1`);
      }
      this.bound = true;
      this.bindError = null;
      this.log(`[bridge] listening on localhost:${this.port}`);
      return true;
    } catch (e) {
      await this.stop();
      this.bindError = e.code === "EADDRINUSE"
        ? `Port ${this.port} is already in use (another Claude session is probably using Webority Figma Write). Use that session, or close it and retry.`
        : `Could not start the bridge on port ${this.port}: ${e.message}`;
      return false;
    }
  }

  async stop() {
    // Drop sockets first: server.close() waits for open connections, and a plugin that
    // reconnects in the meantime would otherwise keep this process alive forever.
    for (const s of this.servers) s.close();
    for (const c of this.wss?.clients ?? []) c.terminate();
    this.plugin?.socket.terminate();
    for (const s of this.servers) s.closeAllConnections?.();
    this.servers = [];
    this.plugin = null;
    this.bound = false;
  }

  hostAllowed(req) {
    return this.allowedHosts.has(String(req.headers.host || "").toLowerCase());
  }

  onUpgrade(req, socket, head) {
    const reject = (status, why) => {
      this.log(`[bridge] rejected upgrade: ${why}`);
      socket.write(`HTTP/1.1 ${status}\r\nConnection: close\r\n\r\n`);
      socket.destroy();
    };
    if (!this.hostAllowed(req)) return reject("421 Misdirected Request", `host ${req.headers.host}`);
    const origin = req.headers.origin;
    if (origin !== undefined && !this.allowedOrigins.includes(origin)) {
      return reject("403 Forbidden", `origin ${origin}`);
    }
    this.wss.handleUpgrade(req, socket, head, (ws) => this.onSocket(ws, origin));
  }

  onSocket(ws, origin) {
    let authed = false;
    const helloTimer = setTimeout(() => {
      if (!authed) ws.close(CLOSE_BAD_TOKEN, "no hello");
    }, 5000);

    ws.on("message", (data) => {
      let msg;
      try {
        msg = JSON.parse(String(data));
      } catch {
        return;
      }
      if (!authed) {
        if (msg?.hello === true && tokenMatches(msg.token, this.token)) {
          authed = true;
          clearTimeout(helloTimer);
          const previous = this.plugin;
          this.plugin = { socket: ws, state: { origin: origin ?? "(none)", version: msg.version ?? null } };
          if (previous && previous.socket !== ws) {
            previous.socket.close(CLOSE_REPLACED, "replaced by another plugin window");
            this.log("[bridge] plugin replaced by a newer window");
          }
          this.log("[bridge] plugin authenticated");
        } else {
          ws.close(CLOSE_BAD_TOKEN, "bad token");
        }
        return;
      }
      if (msg?.type === "state") {
        if (this.plugin?.socket === ws) this.plugin.state = { ...this.plugin.state, ...msg.state };
        return;
      }
      if (typeof msg?.id === "string" && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error != null) reject(new Error(String(msg.error)));
        else resolve(msg.result);
      }
    });

    ws.on("close", () => {
      clearTimeout(helloTimer);
      if (this.plugin?.socket === ws) {
        this.plugin = null;
        this.log("[bridge] plugin disconnected");
      }
    });
  }

  status() {
    return {
      bridge: this.bound ? `listening on localhost:${this.port}` : this.bindError ?? "not started",
      connected: !!this.plugin,
      ...(this.plugin ? this.plugin.state : {}),
    };
  }

  async request(command, params = {}, timeoutMs = 30000) {
    if (!this.bound && !(await this.start())) throw new Error(this.bindError);
    const plugin = this.plugin;
    if (!plugin) {
      throw new Error(
        "No Figma plugin connected. In Figma desktop (design editor, not Dev Mode) run Plugins > Development > 'Webority Figma Write' and keep it open."
      );
    }
    const id = String(++this.seq);
    return await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timed out after ${timeoutMs}ms waiting for the plugin to answer '${command}'.`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: (v) => (clearTimeout(timer), resolve(v)),
        reject: (e) => (clearTimeout(timer), reject(e)),
      });
      plugin.socket.send(JSON.stringify({ id, command, params }), (err) => {
        if (err) {
          clearTimeout(timer);
          this.pending.delete(id);
          reject(new Error("Could not send to the plugin: " + err.message));
        }
      });
    });
  }
}

function listen(server, host, port) {
  return new Promise((resolve, reject) => {
    const onError = (e) => reject(e);
    server.once("error", onError);
    server.listen(port, host, () => {
      server.off("error", onError);
      resolve();
    });
  });
}

function tokenMatches(given, expected) {
  if (typeof given !== "string") return false;
  const a = Buffer.from(given);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
